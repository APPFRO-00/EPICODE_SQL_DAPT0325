-- TASK 2 ESERCIZIO FINALE SQL

CREATE DATABASE toysgroup; #creazione DB toysgroup
USE toysgroup; #utilizzo il DB indicato

#procedo con la creazione di tabelle in ordine di chi ha solo PK, così da collegarne le FK nelle tabelle in cui è richiesta
#creazione tabella region
CREATE TABLE region (
	id_region INT AUTO_INCREMENT PRIMARY KEY,
    NomeRegion VARCHAR(50)
    );
    
#creazione tabella category
CREATE TABLE category (
	id_category INT AUTO_INCREMENT PRIMARY KEY,
    NomeCategoria VARCHAR(50),
    NomeSottocategoria VARCHAR(50)
    );
    
#creazione tabella product
CREATE TABLE product (
	id_product INT AUTO_INCREMENT PRIMARY KEY,
    id_category INT,
    NomeProdotto VARCHAR(100),
    Descrizione VARCHAR(100),
    PrezzoUnitario DECIMAL(10,2),
    QuantitàDisponibile INT,
    FOREIGN KEY (id_category) REFERENCES category(id_category)
    );
    
#creazione tabella country
CREATE TABLE country (
	id_country INT AUTO_INCREMENT PRIMARY KEY,
    NomeCountry VARCHAR(50),
    id_region INT,
	FOREIGN KEY (id_region) REFERENCES region(id_region)
    );
    
#creazione tabella sales
CREATE TABLE sales (
	id_sales INT AUTO_INCREMENT PRIMARY KEY,
    id_product INT,
    id_country INT,
    DataOrdine DATE,
    Cliente VARCHAR(50),
    NomeProdotto VARCHAR(50),
    QuantitàVenduta INT,
    PrezzoUnitario DECIMAL(10,2),
    TotaleVendita DECIMAL(10,2),
    FOREIGN KEY (id_product) REFERENCES product(id_product),
    FOREIGN KEY (id_country) REFERENCES country(id_country)
    );
    
    
-- TASK 3 POPOLAMENTO CAMPI

#popolamento tabella region
INSERT INTO region (NomeRegion)
VALUES 
	('Europa'),
	('Nord America'),
	('Asia'),
	('Sud America'),
	('Oceania');
    
#popolamento campi tabella category
INSERT INTO category (NomeCategoria, NomeSottocategoria)
VALUES
	('Giochi Educativi', 'Puzzle'),
	('Giochi Elettronici', 'Robot'),
	('Bambole e Peluche', 'Bambole'),
	('Veicoli Giocattolo', 'Macchinine'),
	('Sport e Outdoor', 'Palloni');
    
#popolamento campi tabella product
INSERT INTO product (id_category, NomeProdotto, Descrizione, PrezzoUnitario, QuantitàDisponibile)
VALUES 
	(1, 'Puzzle Mondo Animale', 'Puzzle educativo da 100 pezzi con immagini di animali', 19.99, 150),
	(2, 'RoboMax Junior', 'Robot interattivo parlante con luci e suoni', 59.90, 60),
	(3, 'Bambola Caterina', 'Bambola con vestiti intercambiabili e accessori', 29.50, 100),
	(4, 'Auto da Corsa Turbo', 'Macchinina in metallo con motore a retrocarica', 14.99, 200),
	(5, 'Pallone SuperKick', 'Pallone da calcio resistente per uso all’aperto', 24.90, 80);

#popolamento campi tabella country
INSERT INTO country (NomeCountry, id_region)
VALUES
	('Italia', 1),
	('Stati Uniti', 2),
	('Giappone', 3),
	('Brasile', 4),
	('Australia', 5);
    
#popolamento campi tabella sales
INSERT INTO sales (id_product, id_country, DataOrdine, Cliente, NomeProdotto, QuantitàVenduta, PrezzoUnitario, TotaleVendita)
VALUES 
	(1, 1, '2025-01-20', 'Luca Gialli', 'Puzzle Mondo Animale', 3, 19.99, 59.97),
	(2, 2, '2025-02-10', 'Sarah Johnson', 'RoboMax Junior', 1, 59.90, 59.90),
	(3, 3, '2025-03-05', 'Keisuke Honda', 'Bambola Caterina', 2, 29.50, 59.00),
	(4, 4, '2025-04-18', 'Carlos Mendes', 'Auto da Corsa Turbo', 5, 14.99, 74.95),
	(5, 5, '2025-05-22', 'Emily Brown', 'Pallone SuperKick', 2, 24.90, 49.80);
    
-- TASK 4 
#4.1 Verificare che i campi definiti come PK siano univoci
SELECT id_region, COUNT(*) as conteggio
FROM region
GROUP BY id_region
HAVING COUNT(*) > 1;

SELECT id_category, COUNT(*) as conteggio
FROM category
GROUP BY id_category
HAVING COUNT(*) > 1;

SELECT id_country, COUNT(*) as conteggio
FROM country
GROUP BY id_country
HAVING COUNT(*) > 1;

SELECT id_product, COUNT(*) as conteggio
FROM product
GROUP BY id_product
HAVING COUNT(*) > 1;

SELECT id_sales, COUNT(*) as conteggio
FROM sales
GROUP BY id_sales
HAVING COUNT(*) > 1;

#4.2 
SELECT 
	s.id_sales as CodiceDocumento,
    s.DataOrdine,
    p.NomeProdotto,
    c.NomeCategoria,
    r.NomeRegion as NomeContinente,
    n.NomeCountry as NomeNazione,
	IF(DATEDIFF('2025-11-02', s.DataOrdine) > 180, 'TRUE', 'FALSE') as Oltre180giorni
FROM sales s 
	INNER JOIN product p 
	ON p.id_product = s.id_product
    INNER JOIN category c
    ON p.id_category = c.id_category
    INNER JOIN country n 
    ON s.id_country = n.id_country
	INNER JOIN region r 
	ON n.id_region = r.id_region
;

#4.3
SELECT 
    id_product, 
    SUM(TotaleVendita) AS TotaleFatturato
FROM sales
WHERE YEAR(DataOrdine) = 
	(SELECT 
		MAX(YEAR(dataordine))
	FROM sales)
GROUP BY id_product
HAVING SUM(QuantitàVenduta) > 
	(SELECT 
		AVG(QuantitàVenduta)
    FROM sales);

#4.4 Esporre l’elenco dei soli prodotti venduti e per ognuno di questi il fatturato totale per anno.
SELECT
	id_product,
    NomeProdotto,
    SUM(TotaleVendita) as FatturatoTotale,
    YEAR(DataOrdine) as Anno
FROM sales
GROUP BY id_product, NomeProdotto, YEAR(DataOrdine);

#4.5 Esporre il fatturato totale per stato per anno. Ordina il risultato per data e per fatturato decrescente
SELECT 
	c.NomeCountry as Stato,
    SUM(s.TotaleVendita) as FatturatoTotale,
    YEAR(s.DataOrdine) as Anno
FROM sales s
	INNER JOIN country c ON s.id_country = c.id_country
GROUP BY c.NomeCountry, YEAR(s.DataOrdine)
ORDER BY Anno, FatturatoTotale DESC;

#4.6 Rispondere alla seguente domanda: qual è la categoria di articoli maggiormente richiesta dal mercato?
SELECT
	c.NomeCategoria,
	SUM(s.QuantitàVenduta) as QuantitàVenduta
FROM sales s 
	INNER JOIN product p 
	ON p.id_product = s.id_product
	INNER JOIN category c 
    ON p.id_category = c.id_category
GROUP BY c.NomeCategoria
ORDER BY QuantitàVenduta DESC;

#4.7 Rispondere alla seguente domanda: quali sono i prodotti invenduti? Proponi due approcci risolutivi differenti.
-- primo approccio
SELECT 
    p.id_product as CodiceProdotto,
    p.NomeProdotto
FROM product p 
	LEFT JOIN sales s ON p.id_product = s.id_product
WHERE s.id_sales IS NULL;

-- secondo approccio
SELECT 
	NomeProdotto
FROM product
WHERE id_product NOT IN 
		(SELECT id_product
		FROM sales);
        
#4.8 Creare una vista sui prodotti in modo tale da esporre una “versione denormalizzata” delle informazioni utili 
#(codice prodotto, nome prodotto, nome categoria)

CREATE VIEW versione_prodotti AS (
	SELECT 
		p.id_product as CodiceProdotto,
        p.NomeProdotto as NomeProdotto,
        c.NomeCategoria as NomeCategoria
	FROM product p 
		INNER JOIN 	category c 
        ON p.id_category = c.id_category
        );
        
#verifico la creazione della vista
SELECT * FROM versione_prodotti;

#4.9 Creare una vista per le informazioni geografiche
CREATE VIEW info_geografiche as (
	SELECT 
		r.NomeRegion as Continente,
        c.NomeCountry as Nazione,
        s.Cliente as Cliente, 
        p.NomeProdotto as Prodotto,
        cat.NomeCategoria as Categoria,
        s.id_sales as CodiceVendita,
        s.TotaleVendita as TotaleVendita
	FROM sales s 
		INNER JOIN product as p 
        ON s.id_product = p.id_product
        INNER JOIN category as cat 
        ON p.id_category = cat.id_category
        INNER JOIN country as c 
        ON s.id_country = c.id_country
        INNER JOIN region as r 
        ON c.id_region = r.id_region
        );
        
#verifico la creazione della vista
SELECT * FROM info_geografiche;